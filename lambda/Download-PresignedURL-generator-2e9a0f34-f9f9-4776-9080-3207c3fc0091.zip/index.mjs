import { S3Client } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { GetObjectCommand } from "@aws-sdk/client-s3"; //import specific modules instead of full sdk

const s3Client = new S3Client({ region: "us-east-1" }); //instantiate the S3 service here

export const handler = async (event) => {
    try {
        //extract the access token from headers, this will be important later
        const authHeader = event.headers['X-Authorization'];

        //here we validate the access token (placeholder function, to be implemented)
        if (!validateAccessToken(authHeader)) {
            return {
                statusCode: 403,
                body: JSON.stringify({ message: 'Unauthorized' })
            };
        } //end of placeholder authorization section
        
        /*--- TO ALEX ---
        The input for the body of the download request should just be the moduleName 
        as we've set that to be the partition key for the metadata that points to 
        the module's package.    -----> moduleName <-----  
        */

        //the full moduleName should be included in the request body, so that the code knows which package to grab
        const { moduleName } = JSON.parse(event.body);

        //define the parameters for S3 GetObject (grabbing the package)
        const s3Params = {
            Bucket: 'ece461-trustworthy-module-registry', //our S3 bucket name
            Key: moduleName, //module name provided by the front end
        };

        const command = new GetObjectCommand(s3Params);

        //generate the presigned URL for download
        const downloadURL = await getSignedUrl(s3Client, command, { expiresIn: 600 }); //currently set so URL expires in 10 minutes

        //return the presigned URL
        return {
            statusCode: 200,
            body: JSON.stringify({ downloadURL }),
        };
    } catch (error) {
        //handle errors and return a response
        console.error("Error generating presigned URL:", error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Error generating presigned URL', error: error.message }),
        };
    }
};


// Placeholder function for validating the access token
const validateAccessToken = (token) => {
  // Placeholder - add validation logic when implementing Access Control Track
  return true; // For now, assume all requests are authorized
};