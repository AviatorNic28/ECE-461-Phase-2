import { DynamoDBClient, UpdateItemCommand } from "@aws-sdk/client-dynamodb";

//initialize the DynamoDB client
const dynamodb = new DynamoDBClient({ region: "us-east-1" });

export const handler = async (event) => {
  console.log("Received event:", JSON.stringify(event, null, 2));

  //loop through each record in the event (in case of batch processing)
  for (const record of event.Records) {
    if (record.eventName === "ObjectAccessed:Get") {
      const bucketName = record.s3.bucket.name;
      const key = decodeURIComponent(record.s3.object.key.replace(/\+/g, " "));
      console.log(`Processing download event for Bucket: ${bucketName}, Key: ${key}`);

      //extract the module name from the key
      const packageName = key.split('/').pop();

      //here is where we prepare the parameters for DynamoDB update
      const dbParams = {
        TableName: 'ece461-module-metadata2',
        Key: {
          packageName: { S: packageName }
        },
        UpdateExpression: "SET Downloads = if_not_exists(Downloads, :start) + :inc",
        ExpressionAttributeValues: {
          ":inc": { N: "1" },
          ":start": { N: "0" }
        },
        ReturnValues: "UPDATED_NEW"
      };

      try {
        //update the DynamoDB table to increment the Downloads counter by 1
        const result = await dynamodb.send(new UpdateItemCommand(dbParams));
        console.log("Successfully updated download count:", result);
      } catch (error) {
        console.error("Error updating download count:", error);
      }
    }
  }
};
