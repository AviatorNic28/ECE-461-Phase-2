import { DynamoDBClient, PutItemCommand } from "@aws-sdk/client-dynamodb"; //Import DynamoDB client instead of full aws-sdk

const dynamodb = new DynamoDBClient({});  // Instantiate DynamoDB client

/* Sayim and whoever else needs to look at this. This function ACTIVATES 
upon a successful upload straight to a specified S3 bucket. Basically, the actual 
event of a file getting into the bucket is a trigger for this function to start.

Once it starts, it loops through the logs off the S3 bucket event, and collects data
to send to the DynamoDB database. It collects stuff from the built in cloudwatch and s3 logs, 
but also from any info files included in the package. It can collect stuff like package name, 
metric scores, user authorization, whatever we include in the actual file transfer. It's likely 
limited to information transfered and logged by the event, but that can be more than enough.

After collecting all that data through loops and stuff, it puts all that data together in 
a formatted way to send to the dynamoDB tables. It packages it up and automatically sends it 
to whatever DynamoDB location we want to specify. 

After it does all this, it just simply sends a response to the source of the request saying 
the metadata was updated successfully. 

Again, this code is currently triggered by a SUCCESSFUL UPLOAD to the main S3 storage bucket. 

Feel free to message if you have any questions.
*/

export const handler = async (event) => {
    try {
        //debugging log, remove on final vers
        console.log("Incoming Event:", JSON.stringify(event, null, 2));

        // Loop through the S3 event records, to get the information from the latest upload event (which triggers this function)
        for (const record of event.Records) {
            const bucket = record.s3.bucket.name; //these are like pointers to specific info, automatically grabs the latest shit
            const key = record.s3.object.key;

            //debugging log to check the data being passed into the params, remove on final vers
            console.log(`Processing S3 Event for Bucket: ${bucket}, Key: ${key}`);
            
            //new, added for name exceptions
            const [moduleName, fileName, fileType, rating] = key.split('/');

            //debug log to check the extracted names from the key
            console.log(`Extracted Module Name: ${moduleName}`);
            console.log(`Extracted File Name: ${fileName}`);
            console.log(`Extracted File Type: ${fileType}`);
            console.log(`Extracted Rating: ${rating}`);

            //this block prepares metadata for DynamoDB update
            //currently formatted to pass into the "Test" table in dynamoDB
            const dbParams = {
                TableName: 'ece461-module-metadata2',
                Item: {
                    packageName: { S: moduleName }, // this is the partition key for the table, currently set to moduleName
                    version: { S: "1.0.0" }, //sort key, might get patched out
                    Downloads: { N: "0" }, // Initial download count
                    fileName: { S: fileName }, //store file name
                    fileType: { S: fileType }, //store file type
                    UploadedAt: { S: new Date().toISOString() }, // Record timestamp
                    Rating: { N: rating } // store passed in rating 
                    
                }
            };

            //logging the formatted DynamoDB parameters -- debugging | remove for final vers
            console.log("DynamoDB Parameters:", JSON.stringify(dbParams, null, 2));

            //update DynamoDB with package metadata (formatted above)
            await dynamodb.send(new PutItemCommand(dbParams));

            //log success after DynamoDB put operation -- debugging | remove for final vers
            console.log("DynamoDB PutItem Operation Successful");
        }

        //return success response
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Metadata updated successfully' })
        };
    } catch (error) {
        //handle errors and return a response
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Error updating metadata', error: error.message })
        };
    }
};
